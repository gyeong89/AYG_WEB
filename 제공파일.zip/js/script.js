$(function() {

   /* 메인 이미지 슬라이드 기능 구현하기 */
   /* TODO: '.slide-container' 슬라이드 요소에 slick 슬라이드 기능 구현하기 */
   
   
   /* 네비게이션(썸네일) 슬라이드 기능 구현하기 */
   /* TODO: '.slide-nav' 슬라이드 요소에 slick 슬라이드 기능 구현하기 */
   
   
   /* 사이드바 열기 */
   /* TODO: '#menu' 메뉴 버튼 클릭 시, '.side-bar' 사이드바 요소를 출력하기 */
   
   
   /* 사이드바 닫기 */
   /* TODO: '.side-btn' 닫기 버튼 클릭 시, '.side-bar' 사이드바 요소를 숨기기 */


})